# Land-Records-Management-Smart-Contract-Ethereum
Simple land records management with tenant onboarding using smart contract built in solidity for ethereum network
